## all parameters used in this batch of the study: 


### Model and training parameters:
   - neurons_per_layer:         (50, 10)
   - input_shape:               (28, 28)
   - output_shape:              10
   - activation_functions:      relu
   - last_activation_function:  softmax
   - layer_types:               dense
   - loss_function:             categorical_crossentropy
   - training_data_percentage:  0.3
   - number_of_epochs:          50
   - batch_size:                100
   - validation_split:          0.2
   - number_of_repetitions:     5
   - optimizer:                 c_adam
   - learning_rate:             0.1
   - epsilon:                   1e-07
   - beta_1:                    0.9
   - beta_2:                    0.999

### Optimizer parameters:
   - optimizer:                 c_adam
   - learning_rate:             0.1
   - epsilon:                   1e-07
   - beta_1:                    0.9
   - beta_2:                    0.999
